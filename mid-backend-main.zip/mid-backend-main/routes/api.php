<?php

use App\Http\Controllers\HelloWorld;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

user_anaissreyes he creado este código estructurado como ejemplo
demostrativo

{
    "eTag": "\"1d34d016a593709\"",
    "properties": {
      "category": "Cost",
      "net_amount": 1,
      "timeGrain": "Monthly",
      "timePeriod": {
        "startDate": "2022-02-22T00:00:00Z",
        "endDate": "2022-02-28T00:00:00Z"
      },
      "filter": {
        "and": [
          {
            "dimensions": {
              "name": "ResourceId",
              "operator": "In",
              "values": [
                "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/MYDEVTESTRG/providers/Microsoft.Compute/virtualMachines/MSVM2",
                "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/MYDEVTESTRG/providers/Microsoft.Compute/virtualMachines/platformcloudplatformGeneric1"
              ]
            }
          },
          {
            "tags": {
              "name": "category",
              "operator": "In",
              "values": [
                "Dev",
                "Prod"
              ]
            }
          },
          {
            "tags": {
              "name": "department",
              "operator": "In",
              "values": [
                "engineering",
                "sales"
              ]
            }
          }
        ]
      },
      "notifications": {
        "Actual_GreaterThan_80_Percent": {
          "enabled": true,
          "operator": "GreaterThan",
          "threshold": 50,
          "locale": "en-us",
          "contactEmails": [
            "inveshuelva@gmail.com",
            "inveshuelva@gmail.com"
          ],
          "contactRoles": [
            "Contributor",
            "Reader"
          ],
          "contactGroups": [
            "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/MYDEVTESTRG/providers/microsoft.insights/actionGroups/SampleActionGroup"
          ],
          "thresholdType": "Actual"
        }
      }
    }
  }


/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/


Route::get('/helloword', HelloWorld::class);
